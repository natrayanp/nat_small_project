import {Component} from '@angular/core';


@Component({
  selector: 'app-dashboard-view',
  templateUrl: './dashboard-view.component.html',
  styleUrls: ['./dashboard-view.component.scss']
})
export class DashboardViewComponent {

  sidenavRequired = true;
  sidebarRequired = true;
}
